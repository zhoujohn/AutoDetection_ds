package com.frt.autodetection.mvp.ui;

/**
 * ================================================
 * 包名：com.frt.autodetection.mvp.ui
 * 创建人：sws
 * 创建时间：2019/8/2  下午 09:57
 * 描述：
 * ================================================
 */
public class a {
}
