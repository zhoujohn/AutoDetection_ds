package com.frt.autodetection.mvp.iview;

import com.common.mvplib.mvp.IView;

/**
 * ================================================
 * 包名：com.cts.hltravel.client.mvp.iview
 * 创建人：sws
 * 创建时间：2019/5/31  下午 06:21
 * 描述：
 * ================================================
 */
public interface IMainActivityView extends IView {
}
