package com.frt.autodetection.mvp;

/**
 * ================================================
 * 包名：com.frt.autodetection.mvp
 * 创建人：sws
 * 创建时间：2019/8/2  下午 09:56
 * 描述：
 * ================================================
 */
public class a {
}
